crystal build hello.cr
