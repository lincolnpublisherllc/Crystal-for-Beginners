crystal run hello.cr
