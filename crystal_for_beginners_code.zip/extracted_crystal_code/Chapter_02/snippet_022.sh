mkdir hello_world
cd hello_world
