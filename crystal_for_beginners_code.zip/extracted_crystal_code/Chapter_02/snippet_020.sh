crystal build hello.cr
This creates a file (hello.exe on Windows, hello on Linux/macOS) that you can run directly.
