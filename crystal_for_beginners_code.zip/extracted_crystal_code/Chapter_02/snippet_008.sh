curl -fsSL https://crystal-lang.org/install.sh | sudo bash
sudo apt install crystal
