cd foldername
