sudo dnf install crystal
