crystal run filename.cr
