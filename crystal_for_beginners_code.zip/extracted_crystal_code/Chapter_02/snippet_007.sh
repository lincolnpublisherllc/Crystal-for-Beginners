brew install crystal
Verify your installation (Section 2.3).
