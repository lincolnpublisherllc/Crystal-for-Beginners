sudo pacman -S crystal
