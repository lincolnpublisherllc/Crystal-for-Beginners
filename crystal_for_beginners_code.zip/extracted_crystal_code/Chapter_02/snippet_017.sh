cd ..
