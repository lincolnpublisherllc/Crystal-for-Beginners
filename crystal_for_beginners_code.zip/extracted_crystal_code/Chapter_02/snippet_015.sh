ls
(Windows: dir)
