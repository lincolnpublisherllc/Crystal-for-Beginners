# Extracted Code — Crystal for Beginners

This archive contains code-like snippets detected in the manuscript, grouped by chapter.
File extensions are best-effort guesses (.cr for Crystal, .sh for shell/terminal commands, .txt otherwise).

## Chapters
- Chapter 01: 8 snippet(s)
- Chapter 02: 28 snippet(s)
- Chapter 03: 22 snippet(s)
- Chapter 04: 27 snippet(s)
- Chapter 05: 20 snippet(s)
- Chapter 06: 30 snippet(s)
- Chapter 07: 28 snippet(s)
- Chapter 08: 25 snippet(s)
- Chapter 09: 26 snippet(s)
- Chapter 10: 24 snippet(s)
- Chapter 11: 18 snippet(s)
- Chapter 12: 43 snippet(s)

> Note: Detection is heuristic. If something is missing or misclassified, let me know and I can refine the extractor.
